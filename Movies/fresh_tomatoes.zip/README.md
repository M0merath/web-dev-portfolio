# Fresh Tomatoes
_Fresh Tomatoes_ is a movie website that presents important information about selected movies, such as their title, film poster, and synopsis. Click on any film poster to view that film's original trailer in an inset window.

## Contents
* `README.md` (this file which you are reading)
* `fresh_tomatoes.html` (the actual Fresh Tomatoes web page)
* `fresh_tomatoes.py` (contains the code that makes Fresh Tomatoes work)
* `media.py` (creates the template for all movie entries. Includes the "show trailer" function)
* `entertainment_center.py` (contains the movie entries. Add your own favorites!)

## How to start
Double-click the file `entertainment_center.ps` in the same directory as this README. The website will open.

## License
The foundation of this project was created by Udacity as a learning exercise for students. This version was modified by Kevin Lanzing, the student. As I do not claim ownership of the IP, please do not distribute!
